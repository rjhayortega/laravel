<?php
Route::get('ajax',function(){
   return "ASDASD";
});
Route::post('/getmsg','AjaxController@index');