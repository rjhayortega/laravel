<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;



class DBController extends Controller {
	
	
   public function index(){

   }
   
    public function addcomment(Request $request){
      $name = $request->input('name');
	 
		$data= $request->msg;
		$id = $request->id;
		$id = str_replace("#","",$id);
		DB::insert('insert into comments (username,msg,parent) values (?,?,?)', [$name,$data,$id]);
		return "";
   }
   
   
   
    public function selectComments(){
		      $msg = '
<ul class="tree">';

$results = DB::select('select * from comments where parent = ?',[0]);
foreach($results as $r){
	$msg.='
  <li>
    <input type="checkbox" checked="checked" id="'.$r->id.'" />
    <label class="tree_label" for="'.$r->id.'">'.$r->msg.' by '.$r->username.'</label><ul>';
	$results1 = DB::select('select * from comments where parent = ?',[$r->id]);
	
	foreach($results1 as $r1){
	
	$msg.='<li>
	 <input type="checkbox" checked="checked" id="'.$r1->id.'" />
	<label class="tree_label" for="'.$r1->id.'">'.$r1->msg.' by '.$r1->username.'</label>
	
	<ul>';
	
  $results2 = DB::select('select * from comments where parent = ?',[$r1->id]);
	
  foreach($results2 as $r2){
	
	$msg.='<li><label class="tree_label" for="'.$r1->id.'">'.$r2->msg.' by '.$r2->username.'</label></li>
	
  }
  
	<li>
    <table>
	<tr><td valign="top">Name:<textarea id="name_'.$r1->id.'"></textarea></td>
	</tr><tr><td valign="top">
			
	Message:<textarea id="msg_'.$r1->id.'"></textarea></td></tr>
	</table>
	<button onclick=cn("'.$r1->id.'") id="commentNow">Comment</button></li>
	<ul></li>';
  
	}
  
  $msg.='</ul>';
	
 
	}
  
  
  $msg.='
  <li>
    <table>
	<tr><td valign="top">Name:<textarea id="name_'.$r->id.'"></textarea></td>
	</tr><tr><td valign="top">
			
	Message:<textarea id="msg_'.$r->id.'"></textarea></td></tr>
	</table>
	<button onclick=cn("'.$r->id.'") id="commentNow">Comment</button></li>
	</ul></li>';

  }
  
  
  
   $msg.='  </ul>';
      return response()->json(array('msg'=> $msg), 200);
     // $users = DB::select('select * from comments');
           //return response()->json(array('msg'=> $users), 200);
 
   }
   
}